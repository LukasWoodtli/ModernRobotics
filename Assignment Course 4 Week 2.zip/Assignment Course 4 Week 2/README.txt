Sampling-Based Planning
=======================

Assignment of Modern Robotics, Course 4, Week 2 on Coursera.

 Algorithm
 ---------

 A Rapidly exploring Random Trees (RRT) is used to solve the planning problem.
