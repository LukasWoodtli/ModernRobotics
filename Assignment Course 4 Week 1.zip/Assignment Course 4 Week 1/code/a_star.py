import csv
import os.path

from collections import defaultdict

class OpenList:
    """Keep nodes that are still open and
    need to be visited again."""
    def __init__(self):
        self.dict = {}

    def insert(self, value, est_total_cost):
        """Save the node with its estimated
        total cost.
        The values in the dictionary are not
        sorted. The sorting happens when a value
        is retrieved from the list."""
        self.dict[value] = est_total_cost

    def get_first(self):
        """Get the first node according to the estimated cost."""
        key = None
        cost = None
        for k, v in self.dict.items():
            if not cost or v < cost:
                key = k
                cost = v
        assert key
        del self.dict[key]
        return key

    def empty(self):
        """Check if the list is empty."""
        return not bool(self.dict)

class AStar:
    """Implementation of the A* algorithm."""
    def __init__(self, cost_list, heuristic_cost_to_go):
        self.open_list = OpenList()
        self.closed_list = set()
        self.cost = self.init_cost(cost_list)
        self.heuristic_cost_to_go = self.init_heuristic_cost_to_go(heuristic_cost_to_go)
        # first node in the list is considered to be the start
        self.start = heuristic_cost_to_go[0][0]
        # last node in the list is considered to be the goal
        self.end = heuristic_cost_to_go[-1][0]
        # minimum cost so far for node (from start)
        self.past_cost = defaultdict(lambda: 99)
        self.parent = {}
        # add start node to OPEN list
        self.open_list.insert(self.start, self.heuristic_cost_to_go[self.start])
        # past cost for start node is 0 (zero)
        self.past_cost[self.start] = 0

    @staticmethod
    def init_cost(cost_list):
        """Init list with cost per edge."""
        res = defaultdict(lambda: defaultdict(lambda: None))
        for cost in cost_list:
            start, end, cst = cost
            res[start][end] = cst
        # not a directed graph so cost[i][j] == cost[j][i]
        res_cpy = res.copy()
        for i in res_cpy.keys():
            for j in res_cpy[i].keys():
                if i != j:
                    if res_cpy[i][j]:
                        res[j][i] = res[i][j]
        return res

    @staticmethod
    def init_heuristic_cost_to_go(htg):
        """Init the list with the heuristic cost to go."""
        heuristic_cost_to_go = {}
        for i in htg:
            node, cost = i
            heuristic_cost_to_go[node] = cost
        return heuristic_cost_to_go

    def get_neighbors(self, node):
        """Find the neighbors of a node."""
        result = set()
        for k0, v0 in self.cost.items():
            for k1, v1 in v0.items():
                if v0 and v1 and node in (k0, k1):
                    result.add(k0)
                    result.add(k1)
        return result

    def get_neighbors_not_in_closed(self, node):
        """Get the neighbors of a node that are not in the
        CLOSED list."""
        nbrs = self.get_neighbors(node)
        return [n for n in nbrs if n not in self.closed_list]

    def find_path(self):
        """Find the path with the A* algorithm."""
        while not self.open_list.empty():
            current = self.open_list.get_first()
            if current == self.end:
                return self.get_path(self.end)
            self.closed_list.add(current)
            for nbr in self.get_neighbors_not_in_closed(current):
                self.process_neighbor(current, nbr)
        return None

    def process_neighbor(self, current, nbr):
        """Process a neighbor as part of the A* algorithm."""
        tentative_past_cost = self.past_cost[current] + self.cost[current][nbr]
        if tentative_past_cost < self.past_cost[nbr]:
            self.update_best_path(current, nbr, tentative_past_cost)

    def update_best_path(self, current, nbr, tentative_past_cost):
        """Update the best path found so far for a given node."""
        self.past_cost[nbr] = tentative_past_cost
        self.parent[nbr] = current
        est_total_cost = self.past_cost[nbr] + self.heuristic_cost_to_go[nbr]
        self.open_list.insert(nbr, est_total_cost)

    def get_path(self, item):
        """Get the result path."""
        path = []
        nxt = item
        while nxt != self.start:
            path = [nxt] + path
            nxt = self.parent[nxt]
        path = [self.start] + path
        return path


PATH_TO_RESULTS = os.path.join(os.path.split(__file__)[0], "..", "results")

def read_nodes_file():
    """Read the nodes file with the heuristic cost to go for a node.
    The x-y coordinates in the file are ignored as they are not needed
    for the A* algorithm."""
    with open(os.path.join(PATH_TO_RESULTS, 'nodes.csv')) as nodes_f:
        nodes = csv.reader(nodes_f)
        res = []
        for n in nodes:
            # ID,x,y,heuristic-cost-to-go
            node, _, _, ctg = n
            res.append([int(node), float(ctg)])
        return res

def read_edges_file():
    """Read the edges file with the cost between two nodes."""
    with open(os.path.join(PATH_TO_RESULTS, 'edges.csv')) as edges_f:
        nodes = csv.reader(edges_f)
        res = []
        for n in nodes:
            # ID1,ID2,cost
            id1, id2, cost = n
            res.append([int(id1), int(id2), float(cost)])
        return res

def write_path_file(result_path):
    """Write the file with the result path."""
    with open(os.path.join(PATH_TO_RESULTS, 'path.csv'), 'w') as path_f:
        path_csv = csv.writer(path_f)
        path_csv.writerow(result_path)


def test_example():
    """A test for the A* algorithm."""
    heuristic_cost_to_go = [
        [1, 1.4142],
        [2, 1.0762],
        [3, 1.1244],
        [4, 0.8494],
        [5, 0.7604],
        [6, 0.8927],
        [7, 0.5719],
        [8, 0.5014],
        [9, 0.6134],
        [10, 0.3135],
        [11, 0.214],
        [12, 0.0]]

    costs = [
        [12, 11, 0.214],
        [12, 10, 0.3135],
        [12, 8, 0.5014],
        [11, 10, 0.1778],
        [11, 9, 0.4454],
        [10, 7, 0.2586],
        [9, 8, 0.2005],
        [9, 6, 0.2796],
        [9, 5, 0.5994],
        [8, 4, 0.48],
        [7, 4, 0.3417],
        [5, 2, 0.179],
        [4, 3, 0.3517],
        [4, 2, 0.2289],
        [3, 2, 0.2169],
        [3, 1, 0.2903],
        [2, 1, 0.422],
        [7, 5, 0.4402],
        [5, 4, 0.11]]

    a_star = AStar(costs, heuristic_cost_to_go)

    path = a_star.find_path()

    # expected path:
    assert path == [1, 3, 4, 7, 10, 12]

if __name__ == "__main__":
    # Read nodes.csv
    heuristic_cost_to_go = read_nodes_file()
    # Read edges.csv
    costs = read_edges_file()

    a_star = AStar(costs, heuristic_cost_to_go)
    path = a_star.find_path()

    # Write the calculated path to path.csv
    write_path_file(path)
