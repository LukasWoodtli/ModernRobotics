# Overshoot Result for default Task

Name: overshoot
Initial block configuration: (x, y, theta) = (1 m, 0 m, 0 rad)
Goal block configuration: (x, y, theta) = (0 m, -1 m, -pi/2 rad)
P control gain (k_p): 5
I control gain (k_i): 5
