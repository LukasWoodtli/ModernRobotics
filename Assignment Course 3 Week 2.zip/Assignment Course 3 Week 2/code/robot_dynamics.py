import numpy as np
from modern_robotics import ForwardDynamics, EulerStep

import numpy as np
# UR5 parameters
M01 = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0.089159], [0, 0, 0, 1]]
M12 = [[0, 0, 1, 0.28], [0, 1, 0, 0.13585], [-1, 0, 0, 0], [0, 0, 0, 1]]
M23 = [[1, 0, 0, 0], [0, 1, 0, -0.1197], [0, 0, 1, 0.395], [0, 0, 0, 1]]
M34 = [[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0.14225], [0, 0, 0, 1]]
M45 = [[1, 0, 0, 0], [0, 1, 0, 0.093], [0, 0, 1, 0], [0, 0, 0, 1]]
M56 = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0.09465], [0, 0, 0, 1]]
M67 = [[1, 0, 0, 0], [0, 0, 1, 0.0823], [0, -1, 0, 0], [0, 0, 0, 1]]
G1 = np.diag([0.010267495893, 0.010267495893,  0.00666, 3.7, 3.7, 3.7])
G2 = np.diag([0.22689067591, 0.22689067591, 0.0151074, 8.393, 8.393, 8.393])
G3 = np.diag([0.049443313556, 0.049443313556, 0.004095, 2.275, 2.275, 2.275])
G4 = np.diag([0.111172755531, 0.111172755531, 0.21942, 1.219, 1.219, 1.219])
G5 = np.diag([0.111172755531, 0.111172755531, 0.21942, 1.219, 1.219, 1.219])
G6 = np.diag([0.0171364731454, 0.0171364731454, 0.033822, 0.1879, 0.1879, 0.1879])
Glist = [G1, G2, G3, G4, G5, G6]
Mlist = [M01, M12, M23, M34, M45, M56, M67]
Slist = [[0,         0,         0,         0,        0,        0],
         [0,         1,         1,         1,        0,        1],
         [1,         0,         0,         0,       -1,        0],
         [0, -0.089159, -0.089159, -0.089159, -0.10915, 0.005491],
         [0,         0,         0,         0,  0.81725,        0],
         [0,         0,     0.425,   0.81725,        0,  0.81725]]


def forw_dyn(theta, dtheta):
    """Calculate the joint acceleration for given joint angles
    and joint velocities for the UR5 robot
    :param theta: The list of joint angles
    :param theta: The list of joint velocities
    :return: The resulting joint accelerations"""
    taulist = np.full(shape=6, fill_value=0.)
    g = np.array([0, 0, -9.81]).T
    Ftip = np.full(shape=6, fill_value=0.)
    ddtheta = ForwardDynamics(thetalist=theta,
                              dthetalist=dtheta,
                              taulist=taulist,
                              g=g,
                              Ftip=Ftip,
                              Mlist=Mlist,
                              Glist=Glist,
                              Slist=Slist)
    return ddtheta


def simulate_dyn(theta, dtheta, t_f):
    """Calculate the simulation given the joint angles and
    joint velocities for a given time
    :param theta: The list of joint angles
    :param dtheta: The list of joint velocities
    :param t_f: The duration of the simulation in seconds
    :return: All joint angles (matrix) for the whole simulation"""
    steps_p_s = 1000
    N = steps_p_s * t_f
    dt = float(t_f / N)
    theta_all = np.array([theta])
    for _ in range(N):
        ddtheta = forw_dyn(theta, dtheta)
        theta, dtheta = EulerStep(thetalist=theta, dthetalist=dtheta, ddthetalist=ddtheta, dt=dt)

        # save calculated joint vector in matrix with all iterations
        theta_all = np.vstack([theta_all, theta])
    return theta_all


def robot_dynamics_1():
    """Assignment 1: The robot falling from the zero (home) configuration for 3 seconds"""
    # Set all joint angles to zero (home configuration)
    theta = np.full(shape=6, fill_value=0.)
    # Simulate for 3 seconds
    t_f = 3

    # Set all joint accelerations to zero
    dtheta = np.full(shape=6, fill_value=0.)

    # Simulate the robot dynamics
    theta_all = simulate_dyn(theta, dtheta, t_f)

    # Save matrix with all joint vectors
    np.savetxt("simulation1.csv", theta_all, delimiter=",")


def robot_dynamics_2():
    """Assignment 2: The robot falling from a configuration where all joints are at their
    zero position, except for joint 2, which is at −1 radian.
    This simulation should last 5 seconds."""

    # Initialize all joint angles to zero (home configuration)
    theta = np.full(shape=6, fill_value=0.)
    # Set joint 2, which is at −1 radian
    theta[1] = -1.

    # Simulate for 5 seconds
    t_f = 5

    # Set all joint accelerations to zero
    dtheta = np.full(shape=6, fill_value=0.)

    # Simulate the robot dynamics
    theta_all = simulate_dyn(theta, dtheta, t_f)

    # Save matrix with all joint vectors
    np.savetxt("simulation2.csv", theta_all, delimiter=",")


if __name__ == "__main__":
    # 1. assignment
    robot_dynamics_1()
    # 2. assignment
    robot_dynamics_2()